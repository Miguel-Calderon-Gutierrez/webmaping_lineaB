var map = L.map("map").setView([1.6144, -75.6117], 14); // Establece el centro y el nivel de zoom inicial del mapa

// Define un icono personalizado para las droguerías
const drogueriaIcon = L.icon({
  iconUrl: "/icono.png",
  iconSize: [24, 24],
  iconAnchor: [16, 16],
  popupAnchor: [0, -16],
});

//Configuración capa base de OpenStreetMap
function InitialConfig() {
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a>',
  }).addTo(map);
}
// Capa WMS droguerias de Florencia de GeoServer
function getPointsDroguerias() {
  var wmsLayer = L.tileLayer
    .wms("http://localhost:8080/geoserver/LineaB/wms", {
      layers: "LineaB:drogueriasflorencia",
      format: "image/png",
      transparent: true,

      pointToLayer: function (feature, latlng) {
        return L.marker(latlng, { icon: drogueriaIcon });
      },
    })
    .addTo(map);
}
//Obtener data en json y mostrar las droguerias de florencia
function getDataDroguerias() {
  // URL para la solicitud GET
  const url =
    "http://localhost:8080/geoserver/LineaB/wfs?service=WFS&version=1.1.0&" +
    "request=GetFeature&typeName=LineaB%3Adrogueriasflorencia&output" +
    "Format=application%2Fjson";

  fetch(url)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Error al realizar la solicitud");
      }
      return response.json();
    })
    .then((data) => {
      data.features.forEach((drogueria) => {
        const latlng = [
          drogueria.geometry.coordinates[1],
          drogueria.geometry.coordinates[0],
        ];
        const nombre = drogueria.properties.name;
        const idDrogueria = drogueria.properties.id;
        const marker = L.marker(latlng, { icon: drogueriaIcon }).addTo(map);
        const popupContent = `
    <div>
      <b>Id: ${idDrogueria} - ${nombre}</b>  
    </div>
    <img id="fotoDrogueria" src="${drogueria.properties.photo}"> 
    <br/>
    <button id="btn-${idDrogueria}" class="btn-sm btn-outline-primary">Marcar visita</button>
    `;
        marker.bindPopup(popupContent);

        marker.on("popupopen", () => {
          document
            .querySelector(`#btn-${idDrogueria}`)
            .addEventListener("click", () => {
              registrarVisita(drogueria.geometry);
            });
        });
      });
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}
//formulario para registrar la visita
function registrarVisita(geometry) {
  Swal.fire({
    title: "REGISTRO DE VISITA",
    html: `
      <h2>Nombre:</h2>
      <input type="text" id="nombre" class="swal2-input" placeholder="Nombre">
      <h2>Cedula:</h2>
      <input type="number" id="cc" class="swal2-input" placeholder="123456">`,
    focusConfirm: false,
    preConfirm: () => {
      const nombre = Swal.getPopup().querySelector("#nombre").value;
      const cedula = Swal.getPopup().querySelector("#cc").value;
      if (!nombre || !cedula) {
        Swal.showValidationMessage("Por favor completa ambos campos");
        return false;
      }
      return { nombre: nombre, cedula: cedula, geometry: geometry };
    },
  }).then((result) => {
    if (result.isConfirmed) {
      enviarDatos(result.value);
    }
  });
}
// Función para enviar datos a la DB mediabte la API
function enviarDatos(datos) {
  console.table(datos);
  Swal.fire({
    title: "¡Éxito!",
    text: "Visita registrada en consola",
    icon: "success",
  });
  /* fetch('https://api.ejemplo.com/visitas', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(datos)
  })
  .then(response => response.json())
  .then(data => {
    Swal.fire({
      title: '¡Éxito!',
      text: 'Visita registrada',
      icon: 'success'
    });
  })
  .catch(error => {
    console.error('Error al registrar la visita:', error);
    Swal.fire({
      title: 'Error',
      text: 'No se pudo registrar la visita de '+datos.nombre,
      icon: 'error'
    });
  });*/
}
//Se pide permiso y se obtine la ubicación del cliente
function ubicacionCliente() {
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition((position) => {
      const { latitude, longitude } = position.coords;
      const iconoUsuario = L.icon({
        iconUrl: "/persona.png",
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32],
      });
      L.marker([latitude, longitude], { icon: iconoUsuario })
        .addTo(map)
        .bindPopup("Tú estás aquí")
        .openPopup();
      map.setView([latitude, longitude], 14);
    }, (error) => {
      Swal.fire({
        title: 'Error',
        text: 'No se pudo acceder a la ubicacion :( ',
        icon: 'error'
      });
    });
  } else {
    console.error("La geolocalización no es compatible con este navegador.");
  }
}


//pendiente--------------------------------
function agregarControlBusqueda() {

}




function main() {
  InitialConfig();
  //getPointsDroguerias();
  getDataDroguerias();
  ubicacionCliente();
}

main();
